from telebot.callback_data import CallbackData

for_city = CallbackData('city_id', prefix="search")
for_history = CallbackData('history_id', prefix="history")

